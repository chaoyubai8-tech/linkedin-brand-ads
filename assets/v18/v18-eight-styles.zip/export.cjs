const { chromium } = require('playwright');
const fs = require('node:fs/promises');
const path = require('node:path');
const root = __dirname;
const ids = ['T18-US-01','T18-US-02','T18-EU-01','T18-EU-02','A18-US-01','A18-US-02','A18-EU-01','A18-EU-02'];
(async()=>{
  for (const dir of ['finals','qa']) await fs.mkdir(path.join(root,dir),{recursive:true});
  const browser = await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
  try {
    const page = await browser.newPage({viewport:{width:1200,height:1200},deviceScaleFactor:1});
    await page.goto('file://'+path.join(root,'artwork/index.html'));
    await page.evaluate(async()=>{await document.fonts.ready;await Promise.all([...document.images].map(im=>im.decode()));});
    const report=[];
    for (const id of ids) {
      const el=page.locator('#'+id);
      await el.screenshot({path:path.join(root,'finals',id+'.png')});
      const check=await el.evaluate(ad=>{
        const r=ad.getBoundingClientRect();
        return {id:ad.id,width:r.width,height:r.height,fontLoaded:document.fonts.check('700 100px Instrument'),headline:ad.querySelector('h1').innerText,images:[...ad.querySelectorAll('img')].map(x=>({src:x.getAttribute('src'),loaded:x.naturalWidth>0})),overflow:[...ad.querySelectorAll('h1,p,figcaption,footer,.disclosure,.brand')].filter(n=>{const b=n.getBoundingClientRect();return b.left<r.left||b.right>r.right+1||b.top<r.top||b.bottom>r.bottom+1}).map(n=>n.className||n.tagName)};
      });
      check.bytes=(await fs.stat(path.join(root,'finals',id+'.png'))).size;
      report.push(check);
    }
    await page.addStyleTag({content:'.ad{zoom:.3;margin-bottom:40px}'});
    await page.setViewportSize({width:360,height:360});
    for (const id of ids) await page.locator('#'+id).screenshot({path:path.join(root,'qa',id+'-360.png')});
    await fs.writeFile(path.join(root,'qa/export-audit.json'),JSON.stringify(report,null,2));
    console.log(JSON.stringify(report,null,2));
    if (report.some(r=>r.overflow.length||r.bytes>5e6||!r.fontLoaded||r.width!==1200||r.height!==1200)) process.exitCode=1;
  } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
