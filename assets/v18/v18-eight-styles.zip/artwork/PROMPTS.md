# V18 · AI concept asset prompts

Created 2026-10-09 (Asia/Shanghai). Built-in image_gen only; one new generation per asset. These are AI-generated two-dimensional concept illustrations, not Tripo model outputs, real mesh renders, manufactured products, or production-readiness evidence. No source reference images are used. No typography, branding, UI, or fake wireframe is requested.

## rover

Destination: `assets/rover.png`.

```text
Use case: stylized-concept
Asset type: original two-dimensional game-asset concept for a professional advertising layout; artwork only, not an advertisement.
Scene/backdrop: a premium light-gray seamless photographic studio with a real-looking floor and soft natural contact shadows.
Subject: one original low-slung four-wheel planetary exploration rover with a plausible industrial design. Exactly four wheels, readable refined suspension arms and shock absorbers, a low compact chassis and an integrated compact exploration sensor. This is an unarmed exploration vehicle, not a toy.
Style/medium: exceptionally polished realistic 3D-style concept illustration, sophisticated game production design, clean large forms with restrained functional detail.
Materials/colors: bone-white ceramic-coated body panels, matte graphite structural parts, tactile dark tires, subtle brushed metal joints and restrained amber accents. Distinct realistic material responses, controlled reflections, no excessive dirt or micro-noise.
Composition/framing: square image, at least 1024 pixels per side. Front-side three-quarter view at a moderately low camera angle. The complete rover occupies about 80 percent of image width with comfortable margin on every side; every wheel and extremity remains inside the frame. Show the suspension and front shape clearly.
Lighting/mood: soft front-side studio key light, restrained fill, crisp readable edges and dimensional natural shadows; bright enough to read all principal forms without flat white highlights.
Constraints: original design, no resemblance to a recognizable franchise or branded vehicle, no weapons, no people, no scenery props, no text, no numbers, no labels, no logo, no watermark, no UI, no wireframe. No poster layout or graphic borders. No AI-generated pseudo-technical annotations.
```

## harbor

Destination: `assets/harbor.png`.

```text
Use case: stylized-concept
Asset type: original two-dimensional exploration-game environment concept for an advertising layout; artwork only.
Scene/subject: a compact, beautifully designed sea-cliff harbor settlement for a mature exploration game. A coherent small group of distinctive harbor buildings, ivory-stone arches and connecting bridges, functional bronze harbor mechanisms, a few lake-blue roofs, terraces and piers meeting reflective seawater. Warm window light suggests lived-in spaces. No characters.
Style/medium: high-end cinematic game key art with convincing materials and a carefully art-directed hierarchy of large, medium and small shapes. An original coastal exploration setting, not a generic medieval castle, fairy-tale palace, miniature toy or crowded fantasy metropolis.
Composition/framing: square high-resolution image, at least 1024 pixels per side, with a wide-view composition that also tolerates a landscape crop. The entire important architectural group is compact and readable in the LOWER TWO THIRDS. Reserve the TOP ONE THIRD as very dark, clean, quiet blue dusk sky for later large typography; no tall object, bright cloud, star cluster or mountain occupies that clear title zone. Use one dominant harbor mass, supporting bridge/terrace shapes and controlled depth; do not scatter tiny unrelated buildings.
Lighting/mood: cinematic blue-hour dusk; cool blue ambient light and restrained warm window lights with realistic sea reflections. Principal building faces and bridges remain readable, not crushed to black. Rich yet controlled atmosphere.
Materials/colors: ivory stone, bronze mechanical details, a limited amount of lake-blue roof material, dark blue sea and sky; subtle natural texture, no excessive grunge, detail noise or decorative clutter.
Constraints: no people, no vehicles as focal points, no signs, no text, no numbers, no logo, no watermark, no UI, no frame, no wireframe. This is concept art, not a screenshot or a real generated 3D model.
```

## chair

Destination: `assets/chair.png`.

```text
Use case: product-mockup
Asset type: original two-dimensional furniture product concept for a professional advertising layout; artwork only.
Scene/backdrop: a warm-gray to off-white seamless studio cyclorama with a clean floor.
Subject: one original designer curved lounge chair, a modern sculptural piece of furniture with a structurally plausible continuous curved smoke-gray polished aluminum frame supporting a comfortable caramel-leather seat and reclined back. The upholstery and frame form a graceful, coherent usable construction. No separate footstool or added props.
Style/medium: premium photorealistic product photography of a fictional original design; sophisticated furniture craft, not a copy of an iconic branded chair.
Composition/framing: square high-resolution image, at least 1024 pixels per side. Three-quarter view with the entire chair visible, occupying about 70 percent of the image width, generous clean margin all around and no cropped leg, frame, back or shadow.
Materials/textures: rich caramel leather with fine natural grain, subtle stitching and believable padding tension; smoke-gray polished aluminum with controlled long reflections and a refined sculptural curvature. Materials are realistically different, not uniformly plastic. Very low noise and restrained detail.
Lighting/mood: broad soft side light, gentle fill, clean grounded contact shadow that makes the frame supports legible; warm, calm, premium product presentation. Avoid blown highlights and dark unreadable metal.
Constraints: no person, no room furnishings, no plants, no labels, no text, no numbers, no logo, no watermark, no UI, no wireframe, no decorative borders. This is an AI concept image, not evidence of a real manufactured product or a generated 3D mesh.
```

## Output verification

Completed: three separate built-in image_gen calls, each using the exact prompt above. All three outputs were visually inspected. No correction generation was required; no Tripo call, model generation, manual pixel retouching, background replacement, or image resizing was performed. Source originals remain in place. All deliverables are 1254 × 1254 PNG and were verified byte-for-byte identical to the corresponding generated file.

| Asset | Bytes | SHA-256 | Visual review / layout limits |
| --- | ---: | --- | --- |
| rover | 2,015,547 | `f9b2206f987d2fa503573f6f95048657beaaa278bd463614b3e37018798cf4be` | Complete four-wheel silhouette, readable suspension and distinct tire/body/metal materials. No severe clipping or obvious disconnected suspension. Vehicle fills more width than the requested approximate 80%; preserve the existing side margins when laying out. Large tires and a compact body can suggest a premium RC vehicle; do not describe this concept as engineering-validated. |
| harbor | 2,431,973 | `389ff3c385923d44a91bb087b4fd938414db516d9c63e9ccaf52d6f64b059f20` | Clear ivory arches, bronze harbor mechanisms, cool water and warm windows. Quiet dark sky occupies roughly the upper 28–30%; tallest left tower begins around 29% of canvas height, so keep headline within approximately the upper 27%. Best as a large/full-scene image, not a tiny card. Fine dock details and lower cliff shadows are less readable when reduced. |
| chair | 1,956,372 | `24a321229de435a36e591e02101b981c75f1525c385beddd8a3d725716821213` | Complete chair, leg/frame and natural grounding shadow; caramel leather grain and polished aluminum are clearly differentiated. No severe structural ambiguity seen in this single view. Frame is brighter silver than a dark smoke-gray finish; do not imply tested physical manufacturability. |

## Original generated files

- rover: `/Users/baichaoyu/.codex/generated_images/01a10a65-b21c-7d02-89b2-c46cedbe5b16/exec-c01e7652-ad4a-46b5-90c3-f88e5f73dad2.png`
- harbor: `/Users/baichaoyu/.codex/generated_images/01a10a65-b21c-7d02-89b2-c46cedbe5b16/exec-81dcad11-4b7f-4052-933f-362187f5b8a6.png`
- chair: `/Users/baichaoyu/.codex/generated_images/01a10a65-b21c-7d02-89b2-c46cedbe5b16/exec-b860a4e1-3a51-4f2d-9c88-452d3b7103ea.png`

## Claim boundary

Every item is AI-generated two-dimensional concept artwork. No real 3D mesh, topology, Tripo API output, product performance, tooling integration, manufacturing feasibility or game-ready status is evidenced by these pictures. Advertising typography and product claims are outside these source images.
