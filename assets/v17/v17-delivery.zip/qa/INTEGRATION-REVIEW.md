# V17 审稿页集成验收

2026-10-08 · 本地 `http://127.0.0.1:8784/campaign-v17.html`

## 结论

185 项检查通过，0 项失败；没有浏览器脚本异常或 HTTP 资源错误。本轮只包含 4 套主方向和 2 套 Teams 再营销，没有 BA 对照 tab 或待交付对照稿。

这是网页集成和内容呈现验收，不代表平台批准、产品效果实测或正式投放验收。

## 已检查

- 六套方案逐条切换：标题、人群、正文、状态与 `campaign-v17-data.json` 一致。
- 六张主图均为 1200 × 1200；六张站内信配图均为 300 × 250，加载及 PNG 下载全部返回成功。
- 原图使用 `object-fit: contain`；桌面配图显示 300 × 250，不拉伸。
- 四个人群筛选、两类 tab、状态筛选、空结果重置与大小写兼容的广告 ID 深链正常。
- Subject、Body、CTA、整条站内信、Feed 文案的复制载荷逐字匹配数据。测试中拦截 `clipboard.writeText` 验证载荷，未改用户系统剪贴板；另测了权限失败提示。
- 再营销 CTA 分离正确：R17-US Message 为 `Request a trial`，R17-EU Message 为 `Share your needs`；二者 Feed 均为 `Learn more`。
- 所有示意 CTA 是无导航、无发送动作的文字标签；来源链接与 PNG 下载保持单独入口。
- 320 / 360 / 768 / 1440px 下，六套方案均无横向溢出。手机审稿隐藏桌面侧栏配图，保留配图查看和下载链接。
- 历史站内信入口可用；V8 的 6 条 originals + 2 条 suggested 全部保留，US 3 / EU 3 / NEW 2 的切换、主题和配图均正常。
- 已实际查看六张桌面截图、手机图文与消息截图，以及全部六张原尺寸站内信配图。

## 数据措辞提醒

初次验收时，两个再营销的 `status` 为 `needs-evidence`，但 `artwork.label` 仍含“可审稿”。已向内容负责人提出移除此状态词或改为“版式待补证据”，本次没有直接改写活动数据。

## 证据文件

- `integration-results.json`：逐项测试结果。
- `integration-{T17-US,T17-EU,A17-US,A17-EU,R17-US,R17-EU}-desktop.png`：六套桌面视图。
- `integration-T17-EU-mobile360.png`：360px 图文视图。
- `integration-R17-US-message-mobile360.png`：360px 站内信视图。

说明：首次旧数据计数断言误按 `ads` 数组读取，已按该历史文件原有的 `originals + suggested` 结构纠正并复测；这不是网站数据回归。测试使用本机 Chrome 无头浏览器与视口模拟，未进行真实手机设备或线上 GitHub Pages 验收。
